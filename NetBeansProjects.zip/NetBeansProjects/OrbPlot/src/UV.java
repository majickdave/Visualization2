public class UV {
  public float u, v;

  public UV() {
  }

  public UV(float u, float v) {
    this.u = u;
    this.v = v;
  }
}